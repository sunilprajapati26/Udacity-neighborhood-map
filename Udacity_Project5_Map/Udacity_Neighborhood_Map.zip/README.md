# Udacity Neighborhood Map project
	It is amp application that allows you to get recent 	comments about the places using google map api and 	foursquare api.

# Google map Api and Foursquare Api used
 	-Google map api providing information regarding Latitude 	and Longitude of a location.
 	-Foursquare api using client id and client secret. And 	here in this application we are fetching recent comments 	about the venue. 

# To run this project run map.html.